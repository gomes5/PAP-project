import React from 'react';
import Home from './componentes/Home.js';
import Login from './componentes/Login.js';
import Sobre from './componentes/Sobre.js';
import Contacto from './componentes/Contacto.js';
import Cadastro from './componentes/Cadastro.js';
import Nothing from './componentes/Nothing.js';
import Forgot from './componentes/Forgot.js';
import {Routes, Route} from 'react-router-dom';
const App = () =>{
	return(
		<Routes>
			<Route path="/" element={<Home />} />
			<Route path='/home' element={<Home />} />
			<Route path='/login' element={<Login />} />
			<Route path='/contacto' element={<Contacto />} />
			<Route path='/sobre' element={<Sobre />} />
			<Route path='/cadastro' element={<Cadastro />} />
			<Route path='/forgot' element={<Forgot />} />
			<Route path='*' element={<Nothing />} />	
		</Routes>
	);
}
export default App;
