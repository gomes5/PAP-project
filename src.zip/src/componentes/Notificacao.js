import React from 'react';
const Notificao = ({content,title}) =>{
	return(
		<div>
			<h1 className="display-1">{title}</h1><hr />
			<p className="text-secondary">{content}</h1>
		</div>
	);
}
export default Notificacao;
