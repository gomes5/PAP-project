import React from 'react';
const Nothing = () =>{
	return(
		<div>
			<h1 className="display-1">HTTP 404</h1><hr />
			<h1 className="text-secondary">Nothing Found!</h1>
		</div>
	);
}
export default Nothing;
