import React from 'react';
import './Home.css';
import CIcon from '@coreui/icons-react';
import * as icon from '@coreui/icons';
import {Link} from 'react-router-dom';
const Login = () =>{
	return(
		<div className="container-fluid w-30 border-info shadow h-50 bg-light p-3 mt-5 borda">
			<h1 className="text-center"><CIcon className="text-secondary user mx-auto d-block" icon={icon.cilUser} /><span className="small text-secondary">Usuário</span></h1>
			<form className="mx-auto" action="http://localhost:8081/api/login.php" method="post">
			<div className="form-floating my-4">
				<input type="text" name="nome" className="borda form-control" placeholder="nome" id="nome"/>
				<label for="nome" class="borda text-primary form-label">Nome de Login</label>
			</div>
<div className="form-floating my-4">
				<input type="password" name="pass" className="borda form-control" placeholder="pass" id="pass"/>
				<label for="pass" class="text-primary form-label">Palavra Passe</label>
			</div>
			<input type="submit" className="btn borda btn-outline-primary w-100" value="Enviar" />
			</form>
			<Link to="/cadastro" className="link-primary link mt-4 d-block">Cadastrar</Link>
			<Link to="/forgot" className="link-info link d-block">Esqueceu a palavra passe?</Link>
		</div>
	);
}
export default Login;
