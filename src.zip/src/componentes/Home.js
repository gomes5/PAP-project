import React from 'react';
import {Link} from 'react-router-dom';
import CIcon from '@coreui/icons-react';
import * as icon from '@coreui/icons';
import './Home.css';
const Home = () =>{
	return (
		<div>
		<header className="bg-dark">
			<h1 className="px-4 text-light">FreeLancer Network</h1>
			<nav className="px-4 nav bg-light nav-tabs">
				<h2 className="text-dark px-5 pe-5">Logotipo</h2>
				<Link to="/" className="active nav-link px-4"><CIcon className="icon" icon={icon.cilInstitution} /></Link>
				<Link to="/login" className="nav-link px-4"><CIcon className="icon d-block mx-auto" icon={icon.cilGroup} /><span className="small">Login</span></Link>
				<Link to="/sobre" className="nav-link px-4"><CIcon className="icon d-block mx-auto" icon={icon.cilInfo} /><span className="small">Sobre</span></Link>
				<Link to="/contacto" className="nav-link px-4"><CIcon className="icon mx-auto d-block" icon={icon.cilContact} /><span className="small">Contacto</span></Link>
			</nav>
		
		</header>
		
    
		<div className="container w-75 p-5">
		<h1><p className="display-6">Face a um Mundo tecnologicamente evolutivo surge o <span className="text-muted">Freelancer Network</span>!</p></h1>
		<article className="text-secondary lead text-start w-50 h-50">
		<p>O freelancer Network é um sistema inovador que conecta freelancers a oportunidades de trabalho no mundo digital.
</p></article>
		<div className="container">
			<h1>Deseja trabalhar mesmo estando em casa?</h1> 
			<p className="w-50 text-muted lead">O Freelancer Network possibilita trabalhar em casa, bastando simplesmente possuir internet e um PC portátil ou desktop.</p>
		</div>
		<h1><p className="display-6">Conecte-se em Mundo onde os <Link to="/login" className="text-primary link">Sonhos</Link> tornam-se realidades. Torne o seu <Link to="/login" className="text-primary link">Projecto</Link> real.</p></h1>
		<article className="text-secondary text-start lead w-50 h-50"><p>Se fores especializado em alguma área das TIC's ou se estás a procura de alguém para realizar um projecto não esites em <Link to="/cadastro" className="text-info link">Cadastrar-se</Link>.</p></article>
		<h6 className="m-5">Freelancer Network: trabalhe em casa!</h6>
		</div>
		<div className="row m-0">
		<div className="fixed-bottom bg-light text-secondary p-4 mt-5 position-relative">
			<div className="section ms-4 col-2 col-md-2 col-lg-2">
			<p className="display-6">Links</p>
			<Link to="/home" className="small text-primary link d-block">HOME</Link>		
			<Link to="/login" className="small text-primary link d-block">Login</Link>
			<Link to="/sobre" className="small text-primary link d-block">Sobre</Link>
			<Link to="/contacto" className="small text-primary link d-block">Fale conosco!</Link>
			<Link to="/cadastro" className="small text-primary link d-block">Cadastre-se</Link></div>
			<div className="section col-5 mx-4 col-md-5 col-lg-5">
			<p className="display-6">Freelancer Network</p>
			<p className="lead w-75">O freelancer Network é um sistema inovador que conecta freelancers a oportunidades de trabalho no mundo digital.
</p></div>
			<div className="col-4 col-md-4 col-lg-4 section">
			<p className="display-6">Endereço</p>
			<p className="small text-dark text-start d-block"><CIcon className="icon mx-2" icon={icon.cilInstitution} /><span>Telemóvel +244 996 64 45 10</span></p>		
			<p className="small text-dark text-start d-block"><CIcon className="icon mx-2" icon={icon.cilInstitution} /><span>Email freelancernetwork.ao@gmail.com</span></p>
			<p><CIcon className="icon mx-2 text-light" icon={icon.cibFacebookF} /> <CIcon className="icon mx-2 text-light" icon={icon.cibInstagram} /> <CIcon className="icon mx-2 text-light cor" icon={icon.cibWhatsapp} /> <CIcon className="icon mx-2 text-light" icon={icon.cibTwitter} /></p>
			</div>
		</div>
		</div>
	<footer className="w-100 bg-dark text-light p-3">
		<hr className="text-light w-50 container" />
		<p className="text-center p-3 small">&copy;Copy Right {(new Date()).getFullYear()}: Freelancer Network</p>
	</footer>
		</div>
	);
}

export default Home;
