import React from 'react';
import './Home.css';
import CIcon from '@coreui/icons-react';
import * as icon from '@coreui/icons';
import {Link} from 'react-router-dom';
const Forgot = () =>{
	return(
		<div className="container-fluid w-50 border-info shadow h-50 bg-light p-3 mt-5 borda">
			<h1 className="text-center"><CIcon className="text-secondary user mx-auto d-block" icon={icon.cilAddressBook} /><span className="small text-secondary">Usuário</span></h1>
			<h4 className="lead text-center fw-bold">Coloque o seu nome de login e depois verifique o seu email</h4>
			<form className="mx-auto" action="http://localhost:8081/api/forgot.php" method="post">
			<div className="form-floating my-4">
				<input type="text" name="nome" className="borda form-control" placeholder="nome" id="nome"/>
				<label for="nome" class="borda text-primary form-label">Nome de Login</label>
			</div>
			<input type="submit" className="btn borda btn-outline-info mb-5 btn-lg w-100" value="Enviar" />
			</form>
		</div>
	);
}
export default Forgot;
