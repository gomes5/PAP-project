import React,{useState} from 'react';
import './Home.css';
import CIcon from '@coreui/icons-react';
import * as icon from '@coreui/icons';
const Cadastro = () =>{
	const [freelc, setFreelc] = useState("d-none");
	const [select, setSelect] = useState("disable");
	let actual = "btn btn-outline-info mt-4 p-4 w-25 fw-bold " + select;
	let actual2 = "col-3 col-lg-5 col-md-4 container border borda border-info bg-white shadow pt cadastro p-3 mx-5 " + freelc
	return(
		<div className="container-fuid bg-light p-3 borda">
			<h1 className="text-center"><CIcon className="user text-secondary mx-auto d-block" icon={icon.cilUserPlus} /><span className="small text-secondary">Cadastro</span></h1>
			<form className="mx-auto" action="http://localhost:8081/api/cadastro.php" method="post">
			<section className="container">
			<div className="row justify-content-center">
			<article className="col-3 col-lg-5 col-md-4 bg-white shadow pt borda border border-info">
			<div className="form-floating my-4">
				<input requerid type="text" name="nome" className="borda form-control" placeholder="nome" id="nome"/>
				<label for="nome" class="borda text-primary form-label">Nome Completo</label>
			</div>
			<div className="form-floating my-4">
				<input requerid type="text" name="login" className="borda form-control" placeholder="login" id="login"/>
				<label for="login" class="text-primary form-label">Login</label>
			</div>
			<div className="form-floating my-4">
				<input type="email" requerid name="mail" className="borda form-control" placeholder="email" id="mail"/>
				<label for="mail" class="text-primary form-label">Endereço de email</label>
			</div>
<div className="form-floating my-4">
				<input type="password" requerid name="pass" className="borda form-control" placeholder="pass" id="pass"/>
				<label for="pass" class="text-primary form-label">Palavra Passe</label>
			</div>
			<div className="form-floating my-4">
				<input type="text" requerid pattern="[B-O]{2}[0-9]{9}" title="Coloca apenas o número do Bilhete de Identidade. Ex.: 9988767BO45665" name="binumber" id="binumber" placeholder="binumber" className="borda form-control text-success" />
				<label for="binumber" className="text-primary form-label">Nº BI</label></div>
			</article>
			<article className={actual2}>
				<div className="form-floating my-4">
				<input requerid type="text" name="inst" id="inst" placeholder="inst" className="form-control borda text-success" />
				<label for="inst" className="form-label text-primary">Nome da Instituição</label></div>
				<div className="form-floating my-4">
				<input requerid type="email" name="instmail" id="instmail" placeholder="instmail" className="form-control borda text-success" />
				<label for="instmail" className="form-label text-primary">Email da Instituição</label></div>
				<div className="form-floating my-4">
				<input type="text" requerid pattern="[0-9]{9}" title="Coloca apenas o número de telefone. Ex.: 998877665" name="number" id="instnumber" placeholder="instnumber" className="borda form-control text-success" />
				<label for="instnumber" className="text-primary form-label">Número da Instituição</label></div>
				<div className="form-floating my-4">
				<input type="text" requerid pattern="" title="Coloca apenas o NIF" name="nif" id="nif" placeholder="nif" className="borda form-control text-success" />
				<label for="nif" className="text-primary form-label">Número de Identificação Fiscal</label></div>
				<label for="area" className="form-label text-primary">Area(s) Especializada</label>
				<select id="area" name="area" className="text-primary form-select" multiple="multiple">
					<option className="text-info" value="Design">Design</option>
					<option selected className="text-info" value="Web">Desenvolvimento Web</option>
					<option value="Mobile" className="text-info">Desenvolvimento Mobile</option>
					<option value="TI" className="text-info">TI(Redes de Computadores)</option>
					<option value="UIX" className="text-info">UIX/UI</option>
					<option className="text-info" value="Desktop">Desenvolvimento Desktop</option>
				</select>
			</article>
			</div>
			<div className="row justify-content-center">
			<button type="button" name="check" onClick={ () => {if(freelc=="d-none"){ setFreelc("visible"); setSelect("active");} else{ setFreelc("d-none"); setSelect("disable");}}} className={actual} title="Caso pretenda se cadastrar como Freelancer clique aqui!">Freelancer</button>
			</div>
			<div className="container w-50">
			<input type="submit" className="btn borda m-4 my-5 w-100 btn-outline-primary" value="Enviar" /></div></section>
			</form>
		</div>
	);
}
export default Cadastro;
