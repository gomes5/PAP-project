<?php
	$hostname = 'localhost';
	$username = 'hackerone';
	$password = 'hartambull';
	$database = 'mysql';
	$db_name = 'pap';
	try{
		$conexao = new PDO("$database:host=$hostname;dbname=$db_name",$username,$password);
	}
	catch(PDOException $erro){
		echo $erro->getMessage();
	}
?>
