<?php
	echo "Olá Mundo!";	
?>
